const start = new Date().getTime();

function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	NewAtm = new atm();
	NewGround = new ground();
	NewBall = new ball();
	NewTRam = new trampoline();

	prew = 1;
	textSize(32);
	textAlign(CENTER);
	text('Welcome to the simulator of the ball', windowWidth / 2, windowHeight / 2);
	text('Choose the density of material or enter your own', windowWidth / 2, windowHeight / 2 + 100);
	wood = createButton('wood');
	iron = createButton('iron');
	own = createInput();
	cont = createButton('continue');
	wood.position(windowWidth / 2 - 200, windowHeight / 2 + 200);
	iron.position(wood.x + 100, wood.y);
	own.position(iron.x + 100, wood.y);
	cont.position(own.x + own.width, wood.y);
	wood.mousePressed(endPR);
	iron.mousePressed(endPR);
	stopp = 0;


}

function draw() {
	if (prew == 0) {
		background(100);
		wood.remove();
		iron.remove();
		own.remove();
		cont.remove();
		NewAtm.draw();
		NewGround.draw();
		NewBall.draw();
		NewTRam.draw();
		////////////////////////////text///////////////////////////////////////////////////////////
		textAlign(LEFT);
		textSize(32);
		text(`speed: ${NewBall.vy}`, NewBall.tx, NewBall.ty);
		text(`acceleration: ${NewAtm.g}`, NewBall.tx, NewBall.ty + 50)
		text(`potential energy: ${NewBall.ep}J`, NewBall.tx, NewBall.ty + 100)
		text(`kinetic energy: ${NewBall.ek}J`, NewBall.tx, NewBall.ty + 150)
		text(`time: ${Math.trunc(NewBall.t)}ms`, NewBall.tx, NewBall.ty + 200)
		text(`high: ${Math.floor(NewGround.y-NewBall.h)}m`, NewBall.tx, NewBall.ty + 250);
		text(`mass: ${NewBall.m}kg`, NewBall.tx, NewBall.ty + 300);
		text('1 px = 1 metre',NewBall.tx, NewBall.ty + 350);
		
		pause = createButton('stop');
		pause.position(windowWidth / 2, 50);
		pause.mousePressed(stop);
	}

}

function endPR() {
	prew = 0;
}

function stop() {
	if (stopp == 0) {
		lvy = NewBall.vy;
		lg = NewAtm.g;
		lt = NewBall.t;
		ltp = NewBall.tp;
		NewAtm.g = 0;
		NewBall.vy = 0;
		NewBall.tp = 0;
		stopp = 1;

	} else {
		NewBall.vy = lvy;
		NewAtm.g = lg;
		NewBall.t = lt;
		NewBall.tp = 0;
		stopp = 0;
	}
}

const end = new Date().getTime();