class ground{
	constructor(){
		this.y = 600;
	}
	draw(){
	line(0,this.y,windowWidth,this.y);
	}
}