class trampoline {
	constructor() {
		this.l = windowWidth / 4; //length
		this.k = 3000; //stiffness koefficient//H/m
		this.h = 100; //height
		this.x = windowWidth / 4;
		this.l1 = 100; //width
		this.y = windowHeight / 2;
		this.x1 = this.x + this.l / 4;
		this.x2 = this.x + this.l * 0.75;
		this.y1 = this.y;
		this.y2 = this.y;
		this.delx = sqrt((NewBall.m * NewAtm.g * NewBall.y) / this.k);
	}
	draw() {
		fill(255);
		rect(this.x, this.y, this.l1, this.h);
		rect(this.x + this.l, this.y, this.l1, this.h);
		bezier(this.x + this.l1, this.y, this.x1, this.y1, this.x2, this.y2, this.x + this.l, this.y);
	}
}