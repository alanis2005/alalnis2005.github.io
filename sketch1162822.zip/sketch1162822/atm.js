class atm {
	constructor() {
		this.g = 9.8 //random(0.5,10);//gravitation
		this.w = 0 //random(0,10);		//wind
		//	atms = [];
	}
	draw() {

	}
}