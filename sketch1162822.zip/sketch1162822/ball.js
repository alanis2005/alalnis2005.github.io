class ball {
	constructor() {
		this.p = Math.floor(random(600)); //density
		this.r = random(20, 100); //radius
		this.P = NewAtm.g * this.m; //weight
		this.m = this.p * 4 / 3 * 3.14 * Math.pow(this.r, 3);
		this.x = windowWidth / 2;
		this.y = windowHeight / 2;
		//////////////////////////////kinematics/////////////////
		this.t = 0; //time
		this.vy0 = 0;
		this.vy = 0//this.vy0 + NewAtm.g * this.t;
		this.h = 0//this.y + this.vy * this.t + Math.pow(this.t, 2) * NewAtm.g / 2
		this.ep = 0//this.m * this.h * NewAtm.g;
		this.ek = 0//this.m * Math.pow(this.v, 2) / 2;
		//////////////////////////text///////////////////////
		this.tx = windowWidth / 20
		this.ty = windowHeight / 20
		this.tp = 1 / 60;
	}
	draw() {
		this.vy = this.vy0 + NewAtm.g * this.t;
		this.h = this.y + this.vy * this.t + Math.pow(this.t, 2) * NewAtm.g / 2
		this.ep = this.m * (NewGround.y-NewBall.h) * NewAtm.g;
		this.ek = this.m * Math.pow(this.v, 2) / 2;
		this.t += this.tp; //(end - start) / 1000
		fill(255);
		ellipse(this.x, this.y, this.r, this.r);
		////////////////////////////////gravitation//////////////////////////////////////////////////////////// 
		this.y = this.h;
		this.x += NewAtm.w;
		if (this.y >= NewGround.y) {
			this.h = Newground.y;
			this.vy = 0;
		}
	}
}