class pause {
  constructor(){
		
	}
}